# Customizing for Your Industry

This system is industry-agnostic. The AI agents don't care what you sell — they generate content, find opportunities, and manage your presence regardless of niche.

## Quick Customization Checklist

1. **Update `.env`** with your brand info and API keys
2. **Edit agent prompts** in `jobs.json` — swap `[YOUR BRAND]` placeholders
3. **Modify content topics** in each script's TOPICS list
4. **Update website template** with your branding

## Industry Examples

### Plumbing / Home Services
```
Brand story: "Licensed plumber who uses AI to run the business side"
Content angle: Emergency tips, seasonal maintenance, cost-saving advice
Keywords: plumber, emergency repair, water heater, drain cleaning
CTA: "Book online" or "Get a free estimate"
```

### Real Estate
```
Brand story: "Realtor who never sleeps — AI finds your dream home 24/7"
Content angle: Market updates, buying tips, neighborhood guides
Keywords: homes for sale, mortgage rates, first-time buyer
CTA: "See listings" or "Free home valuation"
```

### Fitness / Personal Training
```
Brand story: "Your AI fitness coach available around the clock"
Content angle: Workout tips, nutrition advice, transformation stories
Keywords: workout, meal prep, weight loss, muscle building
CTA: "Start your plan" or "Free consultation"
```

### Freelance / Consulting
```
Brand story: "Consultant with an AI-powered back office"
Content angle: Industry insights, productivity tips, case studies
Keywords: consulting, strategy, growth, optimization
CTA: "Book a call" or "See our work"
```

### E-commerce
```
Brand story: "Products that sell themselves — AI handles the rest"
Content angle: Product showcases, behind-the-scenes, customer stories
Keywords: [your product category], deal, new arrival, review
CTA: "Shop now" or "Limited stock"
```

## What to Customize in Each File

### jobs.json (AI Agents)
- Agent prompts (the `message` field) — make them your voice
- Schedule times — match your audience's timezone
- Channel/user IDs — your Telegram channel and DMs

### auto-post.py
- `TOPICS` list — what your audience cares about
- `BRAND_NAME` and `WEBSITE_URL` — your details
- Post frequency — adjust crontab timing

### twitter-engage.py
- `SEARCH_KEYWORDS` — terms your potential customers use
- `MONITOR_ACCOUNTS` — competitors to piggyback off
- Rate limits — start conservative, scale up

### blog-generator.py
- `BLOG_TOPICS` — SEO-targeted topics for your niche
- HTML template — match your website's look
- Publishing frequency — daily or weekly

## Voice and Tone Tips

The AI will mirror whatever tone you set in the prompts. Examples:

**Professional:**
> "Write in a professional but approachable tone. Use data and case studies."

**Casual:**
> "Write like you're texting a friend about your business. Keep it real."

**Authority:**
> "Write as an industry expert sharing insights. Be definitive and confident."

**Storytelling:**
> "Write like you're telling a story around a campfire. Draw people in."

## Advanced Customization

For deeper customization including:
- Multi-model AI fallback chains
- Industry-specific agent templates
- Custom delivery routing
- Advanced Telegram bot features (inline keyboards, payments)
- White-label configurations

Visit: https://Zombie760.github.io/#pricing
