# Troubleshooting Guide

Common issues and how to fix them. If you're stuck, reach out: https://Zombie760.github.io

## Telegram Bot Issues

### Bot doesn't respond to messages
1. Check the gateway is running: `openclaw status`
2. Verify your bot token: `curl https://api.telegram.org/bot<TOKEN>/getMe`
3. Check gateway logs for connection errors
4. Make sure no other instance is polling the same bot token

### Bot responds but cron jobs don't fire
1. Verify jobs.json is valid JSON: `python3 -m json.tool < jobs.json`
2. Check that `enabled` is `true` for each job
3. Look for schedule errors in the `expr` field
4. Restart the gateway after config changes

### Messages not appearing in channel
1. Confirm the bot is admin in the channel
2. Verify the channel ID is correct (should be negative number)
3. Check that the bot has "Post Messages" permission
4. Test with: `curl -X POST "https://api.telegram.org/bot<TOKEN>/sendMessage" -d "chat_id=<CHANNEL_ID>&text=test"`

## Twitter API Issues

### 401 Unauthorized
- Regenerate all four Twitter credentials
- Make sure your app has "Read and Write" permissions
- After changing permissions, you MUST regenerate tokens

### 403 Forbidden
- Free tier: 500 posts/month limit
- Check if your developer account is suspended
- Verify app is in a Project (required by Twitter v2)

### Rate limiting (429)
- The engagement script has built-in delays
- Reduce `MAX_FOLLOWS_PER_RUN` and `MAX_LIKES_PER_RUN`
- Twitter free tier has strict limits — space out cron runs

### Tweets posting but no images
- Image generation requires specific API configuration
- Check your AI provider supports image generation
- Verify the image URL is accessible before attaching

## AI/API Issues

### Empty or no AI responses
1. Test your API key:
```bash
curl https://api.x.ai/v1/chat/completions \
  -H "Authorization: Bearer $XAI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"grok-3-mini","messages":[{"role":"user","content":"hello"}]}'
```
2. Check account credits/billing
3. Try a different model if available

### AI content quality is low
- Add more context to your prompts in jobs.json
- Include your brand voice description
- Provide examples of good content
- Increase temperature for variety or decrease for consistency

## Blog Generator Issues

### Git push fails
1. Verify GitHub token has `repo` scope
2. Check git remote: `git remote -v`
3. Make sure you've cloned (not just created) the repo
4. Test: `git push --dry-run`

### Blog posts look bad
- Edit the HTML template in blog-generator.py
- Add your website's CSS
- The basic template is intentionally minimal

## Crontab Issues

### Scripts not running
1. Check crontab is saved: `crontab -l`
2. Verify Python path: `which python3`
3. Check log files for errors
4. Make sure scripts are executable: `chmod +x scripts/*.py`

### Scripts run but fail silently
- Always check the log files in your logs directory
- Add `2>&1` to crontab entries to capture stderr
- Test scripts manually first: `python3 scripts/auto-post.py --dry-run`

## OpenClaw Gateway Issues

### Gateway won't start
- Check port 18789 isn't in use: `lsof -i :18789`
- Verify openclaw.json is valid JSON
- Check Node.js version: `node --version` (need 18+)

### Gateway crashes after running
- Check system memory: `free -h`
- Look at gateway logs for error stack traces
- Reduce the number of concurrent agents

### Jobs run but delivery fails
- Verify channel IDs in jobs.json
- Check bot permissions in Telegram
- Look for delivery errors in gateway logs

## Performance

### System using too much RAM
- Reduce concurrent job count
- Use a lighter AI model
- Close unnecessary browser tabs (seriously)

### API costs higher than expected
- Check which model you're using (some cost more)
- Reduce cron frequency during testing
- Use `--dry-run` flags while configuring

## Still Stuck?

- Check the full docs at https://Zombie760.github.io
- DM @moneymakingmitch1904_bot on Telegram
- Most setup issues are resolved with a 30-minute consultation

The full Boss tier ($29/mo) includes priority support and all 13 agents pre-configured.
