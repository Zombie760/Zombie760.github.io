#!/usr/bin/env python3
"""
AI Business Autopilot — Twitter Engagement Bot
Auto-follows, likes, and replies to grow your audience.

Usage:
    python3 twitter-engage.py              # Run engagement cycle
    python3 twitter-engage.py --dry-run    # Preview without actions

NOTE: Requires Twitter API Basic tier for search.
Part of the AI Business Autopilot skeleton.
Full version: https://Zombie760.github.io/#pricing
"""

import os
import sys
import json
import argparse
import logging
import random
import time
from datetime import datetime
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

import tweepy
import requests

# ─── Configuration ────────────────────────────────────────────
BRAND_NAME = os.getenv("BRAND_NAME", "Your Brand")
WEBSITE_URL = os.getenv("WEBSITE_URL", "https://yourdomain.com")

AI_API_KEY = os.getenv("XAI_API_KEY", "")
AI_BASE_URL = os.getenv("AI_BASE_URL", "https://api.x.ai/v1")
AI_MODEL = os.getenv("AI_MODEL", "grok-3-mini")

CONSUMER_KEY = os.getenv("TWITTER_CONSUMER_KEY", "")
CONSUMER_SECRET = os.getenv("TWITTER_CONSUMER_SECRET", "")
ACCESS_TOKEN = os.getenv("TWITTER_ACCESS_TOKEN", "")
ACCESS_TOKEN_SECRET = os.getenv("TWITTER_ACCESS_TOKEN_SECRET", "")

LOG_DIR = Path(os.getenv("LOG_DIR", "logs"))
LOG_DIR.mkdir(exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "engage.log"),
        logging.StreamHandler()
    ]
)
log = logging.getLogger("engage")

# ─── Keywords to search for engagement ───────────────────────
# Customize these for your industry
SEARCH_KEYWORDS = [
    "small business automation",
    "AI for business",
    "side hustle ideas",
    "passive income",
    "solopreneur",
    "business automation tools",
]

# Accounts to monitor (engage with their followers)
MONITOR_ACCOUNTS = [
    # Add Twitter handles of competitors or industry leaders
    # "@competitor1",
    # "@industryleader",
]

# ─── Rate Limits ─────────────────────────────────────────────
MAX_FOLLOWS_PER_RUN = 5
MAX_LIKES_PER_RUN = 10
MAX_REPLIES_PER_RUN = 3

# ─── AI Reply Generation ────────────────────────────────────
def generate_reply(original_tweet: str) -> str:
    """Generate a contextual reply using AI."""
    if not AI_API_KEY:
        return ""

    headers = {
        "Authorization": f"Bearer {AI_API_KEY}",
        "Content-Type": "application/json"
    }

    payload = {
        "model": AI_MODEL,
        "messages": [
            {"role": "system", "content": f"You reply to tweets on behalf of {BRAND_NAME}. Be helpful, genuine, and conversational. Never be salesy. Add value to the conversation. Keep replies under 200 characters."},
            {"role": "user", "content": f"Write a short, genuine reply to this tweet:\n\n\"{original_tweet}\"\n\nJust the reply text, nothing else."}
        ],
        "max_tokens": 100,
        "temperature": 0.8
    }

    try:
        resp = requests.post(
            f"{AI_BASE_URL}/chat/completions",
            headers=headers,
            json=payload,
            timeout=30
        )
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"].strip().strip('"')
    except Exception as e:
        log.error(f"Reply generation failed: {e}")
        return ""


# ─── Twitter Client ──────────────────────────────────────────
def get_twitter_client():
    """Initialize Twitter API client."""
    if not all([CONSUMER_KEY, CONSUMER_SECRET, ACCESS_TOKEN, ACCESS_TOKEN_SECRET]):
        log.error("Twitter credentials not set. Check .env")
        sys.exit(1)

    auth = tweepy.OAuth1UserHandler(
        CONSUMER_KEY, CONSUMER_SECRET,
        ACCESS_TOKEN, ACCESS_TOKEN_SECRET
    )
    api = tweepy.API(auth, wait_on_rate_limit=True)

    try:
        user = api.verify_credentials()
        log.info(f"Authenticated as @{user.screen_name}")
    except Exception as e:
        log.error(f"Auth failed: {e}")
        sys.exit(1)

    return api


# ─── Engagement Actions ─────────────────────────────────────
def engage_with_search(api, dry_run=False):
    """Search for relevant tweets and engage."""
    keyword = random.choice(SEARCH_KEYWORDS)
    log.info(f"Searching for: {keyword}")

    follows = 0
    likes = 0
    replies = 0

    try:
        tweets = api.search_tweets(
            q=keyword,
            lang="en",
            result_type="recent",
            count=20
        )
    except Exception as e:
        log.error(f"Search failed: {e}")
        return {"follows": 0, "likes": 0, "replies": 0}

    for tweet in tweets:
        # Skip retweets and our own tweets
        if hasattr(tweet, "retweeted_status"):
            continue

        # Like tweets
        if likes < MAX_LIKES_PER_RUN:
            try:
                if not dry_run:
                    api.create_favorite(tweet.id)
                likes += 1
                log.info(f"{'[DRY] ' if dry_run else ''}Liked tweet {tweet.id}")
            except Exception:
                pass

        # Follow users (conservative)
        if follows < MAX_FOLLOWS_PER_RUN and not tweet.user.following:
            try:
                if not dry_run:
                    api.create_friendship(user_id=tweet.user.id)
                follows += 1
                log.info(f"{'[DRY] ' if dry_run else ''}Followed @{tweet.user.screen_name}")
            except Exception:
                pass

        # Reply to select tweets (very conservative)
        if replies < MAX_REPLIES_PER_RUN and tweet.favorite_count > 5:
            reply = generate_reply(tweet.text)
            if reply:
                try:
                    if not dry_run:
                        api.update_status(
                            f"@{tweet.user.screen_name} {reply}",
                            in_reply_to_status_id=tweet.id
                        )
                    replies += 1
                    log.info(f"{'[DRY] ' if dry_run else ''}Replied to @{tweet.user.screen_name}: {reply[:60]}")
                except Exception as e:
                    log.error(f"Reply failed: {e}")

        # Respectful delays between actions
        if not dry_run:
            time.sleep(random.uniform(2, 5))

    return {"follows": follows, "likes": likes, "replies": replies}


# ─── Main ────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Twitter Engagement Bot")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    log.info("Starting engagement cycle")
    api = get_twitter_client()

    stats = engage_with_search(api, args.dry_run)
    log.info(f"Engagement complete: {stats['follows']} follows, {stats['likes']} likes, {stats['replies']} replies")


if __name__ == "__main__":
    main()
