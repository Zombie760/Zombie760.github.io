#!/usr/bin/env python3
"""
AI Business Autopilot — Twitter Auto-Poster
Posts AI-generated content to Twitter/X on a schedule.

Usage:
    python3 auto-post.py              # Single post
    python3 auto-post.py --burst      # Thread + cross-post
    python3 auto-post.py --dry-run    # Preview without posting

Part of the AI Business Autopilot skeleton.
Full version: https://Zombie760.github.io/#pricing
"""

import os
import sys
import json
import argparse
import logging
from datetime import datetime
from pathlib import Path

# Load environment
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # Manual env is fine

import tweepy
import requests

# ─── Configuration ────────────────────────────────────────────
BRAND_NAME = os.getenv("BRAND_NAME", "Your Brand")
WEBSITE_URL = os.getenv("WEBSITE_URL", "https://yourdomain.com")
TWITTER_HANDLE = os.getenv("TWITTER_HANDLE", "@yourbrand")

# AI Provider
AI_API_KEY = os.getenv("XAI_API_KEY", "")
AI_BASE_URL = os.getenv("AI_BASE_URL", "https://api.x.ai/v1")
AI_MODEL = os.getenv("AI_MODEL", "grok-3-mini")

# Twitter API
CONSUMER_KEY = os.getenv("TWITTER_CONSUMER_KEY", "")
CONSUMER_SECRET = os.getenv("TWITTER_CONSUMER_SECRET", "")
ACCESS_TOKEN = os.getenv("TWITTER_ACCESS_TOKEN", "")
ACCESS_TOKEN_SECRET = os.getenv("TWITTER_ACCESS_TOKEN_SECRET", "")

# Logging
LOG_DIR = Path(os.getenv("LOG_DIR", "logs"))
LOG_DIR.mkdir(exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "auto-post.log"),
        logging.StreamHandler()
    ]
)
log = logging.getLogger("auto-post")

# ─── Content Topics ──────────────────────────────────────────
TOPICS = [
    "industry tips and tricks",
    "behind the scenes of building a business",
    "motivational content for entrepreneurs",
    "quick wins your audience can implement today",
    "myth-busting common misconceptions",
    "customer success stories",
    "product announcements",
]

# ─── AI Content Generation ───────────────────────────────────
def generate_content(prompt: str) -> str:
    """Call the AI API to generate content."""
    if not AI_API_KEY:
        log.error("No AI API key set. Set XAI_API_KEY in .env")
        sys.exit(1)

    headers = {
        "Authorization": f"Bearer {AI_API_KEY}",
        "Content-Type": "application/json"
    }

    payload = {
        "model": AI_MODEL,
        "messages": [
            {"role": "system", "content": f"You are a social media content creator for {BRAND_NAME}. Website: {WEBSITE_URL}. Write engaging, human-sounding content. Never use hashtags excessively. Sound authentic, not corporate."},
            {"role": "user", "content": prompt}
        ],
        "max_tokens": 500,
        "temperature": 0.9
    }

    try:
        resp = requests.post(
            f"{AI_BASE_URL}/chat/completions",
            headers=headers,
            json=payload,
            timeout=30
        )
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"].strip()
    except Exception as e:
        log.error(f"AI generation failed: {e}")
        return ""


# ─── Twitter Client ──────────────────────────────────────────
def get_twitter_client():
    """Initialize Twitter API client."""
    if not all([CONSUMER_KEY, CONSUMER_SECRET, ACCESS_TOKEN, ACCESS_TOKEN_SECRET]):
        log.error("Twitter credentials not set. Check .env file.")
        sys.exit(1)

    auth = tweepy.OAuth1UserHandler(
        CONSUMER_KEY, CONSUMER_SECRET,
        ACCESS_TOKEN, ACCESS_TOKEN_SECRET
    )
    api = tweepy.API(auth)

    # Verify credentials
    try:
        user = api.verify_credentials()
        log.info(f"Authenticated as @{user.screen_name}")
    except Exception as e:
        log.error(f"Twitter auth failed: {e}")
        sys.exit(1)

    return api


def post_tweet(api, text: str, dry_run: bool = False) -> dict:
    """Post a tweet. Returns the tweet data."""
    # Truncate to Twitter limit
    if len(text) > 280:
        text = text[:277] + "..."

    if dry_run:
        log.info(f"[DRY RUN] Would post: {text}")
        return {"text": text, "id": "dry-run"}

    try:
        status = api.update_status(text)
        log.info(f"Posted tweet {status.id}: {text[:80]}...")
        return {"text": text, "id": status.id}
    except Exception as e:
        log.error(f"Failed to post: {e}")
        return {}


# ─── Post Modes ──────────────────────────────────────────────
def single_post(api, dry_run=False):
    """Generate and post a single tweet."""
    import random
    topic = random.choice(TOPICS)

    prompt = f"""Write a single tweet about: {topic}

Requirements:
- Under 280 characters
- Engaging hook in the first line
- Include a call to action
- Sound human and conversational
- Mention {WEBSITE_URL} naturally if it fits
- No more than 2 hashtags

Just the tweet text, nothing else."""

    content = generate_content(prompt)
    if content:
        return post_tweet(api, content, dry_run)
    return {}


def burst_post(api, dry_run=False):
    """Generate a thread of 4-5 tweets."""
    prompt = f"""Write a Twitter thread (4-5 tweets) about building a business with AI automation.

Requirements:
- Tweet 1: Strong hook that makes people stop scrolling
- Tweets 2-4: Value-packed insights, one per tweet
- Last tweet: CTA pointing to {WEBSITE_URL}
- Each tweet under 280 characters
- Number them 1/, 2/, etc.
- Sound like a real person sharing experience

Format each tweet on its own line, separated by ---"""

    content = generate_content(prompt)
    if not content:
        return []

    tweets = [t.strip() for t in content.split("---") if t.strip()]
    results = []

    previous_id = None
    for tweet_text in tweets:
        if len(tweet_text) > 280:
            tweet_text = tweet_text[:277] + "..."

        if dry_run:
            log.info(f"[DRY RUN] Thread: {tweet_text}")
            results.append({"text": tweet_text})
            continue

        try:
            if previous_id:
                status = api.update_status(
                    tweet_text,
                    in_reply_to_status_id=previous_id
                )
            else:
                status = api.update_status(tweet_text)
            previous_id = status.id
            results.append({"text": tweet_text, "id": status.id})
            log.info(f"Thread tweet {status.id}: {tweet_text[:60]}...")
        except Exception as e:
            log.error(f"Thread tweet failed: {e}")
            break

    return results


# ─── Main ────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="AI Twitter Auto-Poster")
    parser.add_argument("--burst", action="store_true", help="Post a thread")
    parser.add_argument("--dry-run", action="store_true", help="Preview without posting")
    args = parser.parse_args()

    log.info(f"Starting auto-post ({'burst' if args.burst else 'single'} mode)")

    api = get_twitter_client()

    if args.burst:
        results = burst_post(api, args.dry_run)
        log.info(f"Burst complete: {len(results)} tweets")
    else:
        result = single_post(api, args.dry_run)
        if result:
            log.info("Post complete")
        else:
            log.warning("Post failed")


if __name__ == "__main__":
    main()
