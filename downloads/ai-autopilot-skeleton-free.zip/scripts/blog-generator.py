#!/usr/bin/env python3
"""
AI Business Autopilot — SEO Blog Generator
Generates a blog post and pushes it to GitHub Pages.

Usage:
    python3 blog-generator.py              # Generate and push
    python3 blog-generator.py --dry-run    # Preview without pushing

Part of the AI Business Autopilot skeleton.
Full version: https://Zombie760.github.io/#pricing
"""

import os
import sys
import json
import argparse
import logging
import subprocess
from datetime import datetime
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

import requests

# ─── Configuration ────────────────────────────────────────────
BRAND_NAME = os.getenv("BRAND_NAME", "Your Brand")
WEBSITE_URL = os.getenv("WEBSITE_URL", "https://yourdomain.com")
TWITTER_HANDLE = os.getenv("TWITTER_HANDLE", "@yourbrand")

AI_API_KEY = os.getenv("XAI_API_KEY", "")
AI_BASE_URL = os.getenv("AI_BASE_URL", "https://api.x.ai/v1")
AI_MODEL = os.getenv("AI_MODEL", "grok-3-mini")

GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "")
GITHUB_PAGES_REPO = os.getenv("GITHUB_PAGES_REPO", "")  # e.g., username/username.github.io

# Blog output directory (your GitHub Pages repo clone)
BLOG_DIR = Path(os.getenv("BLOG_DIR", os.path.expanduser("~/blog")))

LOG_DIR = Path(os.getenv("LOG_DIR", "logs"))
LOG_DIR.mkdir(exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "blog.log"),
        logging.StreamHandler()
    ]
)
log = logging.getLogger("blog")

# ─── Blog Topics ─────────────────────────────────────────────
# Customize these for your industry
BLOG_TOPICS = [
    "How AI automation saves small businesses time and money",
    "5 tasks every entrepreneur should automate today",
    "The real cost of not using AI in your business",
    "How to start a business with zero employees using AI",
    "Why small businesses are winning with AI before big corporations",
    "From manual labor to automated income: a practical guide",
    "The solopreneur's guide to AI-powered marketing",
    "How to create content 24/7 without hiring a team",
    "Building passive income streams with AI automation",
    "Why the next millionaires will be AI-powered solopreneurs",
]

# ─── AI Content Generation ───────────────────────────────────
def generate_blog_post(topic: str) -> dict:
    """Generate a full blog post using AI."""
    if not AI_API_KEY:
        log.error("No AI API key. Set XAI_API_KEY in .env")
        sys.exit(1)

    headers = {
        "Authorization": f"Bearer {AI_API_KEY}",
        "Content-Type": "application/json"
    }

    payload = {
        "model": AI_MODEL,
        "messages": [
            {"role": "system", "content": f"""You are an SEO blog writer for {BRAND_NAME} ({WEBSITE_URL}).
Write blog posts that:
- Are 500-800 words
- Include relevant keywords naturally
- Have clear H2 and H3 headings
- Include a compelling intro and conclusion
- Add a CTA at the end pointing to {WEBSITE_URL}
- Sound human and authoritative
- Reference {TWITTER_HANDLE} for social proof"""},
            {"role": "user", "content": f"""Write a blog post about: {topic}

Output format:
TITLE: [SEO-optimized title]
SLUG: [url-friendly-slug]
DESCRIPTION: [Meta description, under 160 chars]
---
[Full blog post in markdown]"""}
        ],
        "max_tokens": 2000,
        "temperature": 0.7
    }

    try:
        resp = requests.post(
            f"{AI_BASE_URL}/chat/completions",
            headers=headers,
            json=payload,
            timeout=60
        )
        resp.raise_for_status()
        content = resp.json()["choices"][0]["message"]["content"].strip()

        # Parse the response
        lines = content.split("\n")
        title = ""
        slug = ""
        description = ""
        body = ""

        in_body = False
        for line in lines:
            if line.startswith("TITLE:"):
                title = line.replace("TITLE:", "").strip()
            elif line.startswith("SLUG:"):
                slug = line.replace("SLUG:", "").strip()
            elif line.startswith("DESCRIPTION:"):
                description = line.replace("DESCRIPTION:", "").strip()
            elif line.strip() == "---":
                in_body = True
            elif in_body:
                body += line + "\n"

        if not slug:
            slug = title.lower().replace(" ", "-")[:50]

        return {
            "title": title,
            "slug": slug,
            "description": description,
            "body": body.strip()
        }

    except Exception as e:
        log.error(f"Blog generation failed: {e}")
        return {}


# ─── File Writing ────────────────────────────────────────────
def write_blog_file(post: dict) -> Path:
    """Write the blog post as an HTML file."""
    date = datetime.now()
    filename = f"{date.strftime('%Y-%m-%d')}-{post['slug']}.html"

    blog_dir = BLOG_DIR / "blog"
    blog_dir.mkdir(parents=True, exist_ok=True)

    filepath = blog_dir / filename

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="{post['description']}">
    <title>{post['title']} | {BRAND_NAME}</title>
    <style>
        body {{ font-family: Georgia, serif; max-width: 800px; margin: 0 auto; padding: 20px; line-height: 1.8; color: #333; }}
        h1 {{ color: #1a1a1a; }}
        h2 {{ color: #444; margin-top: 2em; }}
        a {{ color: #c0392b; }}
        .meta {{ color: #888; font-size: 0.9em; margin-bottom: 2em; }}
        .cta {{ background: #c0392b; color: white; padding: 20px; border-radius: 8px; text-align: center; margin: 2em 0; }}
        .cta a {{ color: white; text-decoration: none; font-weight: bold; }}
    </style>
</head>
<body>
    <article>
        <h1>{post['title']}</h1>
        <div class="meta">Published {date.strftime('%B %d, %Y')} by {BRAND_NAME}</div>
        {post['body']}
        <div class="cta">
            <p>Ready to automate your business?</p>
            <p><a href="{WEBSITE_URL}">Get Started with {BRAND_NAME} &rarr;</a></p>
        </div>
    </article>
</body>
</html>"""

    filepath.write_text(html)
    log.info(f"Wrote blog post: {filepath}")
    return filepath


# ─── Git Push ────────────────────────────────────────────────
def git_push(filepath: Path, title: str, dry_run=False):
    """Commit and push the blog post to GitHub Pages."""
    if dry_run:
        log.info(f"[DRY RUN] Would push: {filepath}")
        return True

    try:
        os.chdir(BLOG_DIR)
        subprocess.run(["git", "add", str(filepath)], check=True)
        subprocess.run(
            ["git", "commit", "-m", f"Blog: {title}"],
            check=True
        )
        subprocess.run(["git", "push"], check=True)
        log.info(f"Pushed to GitHub Pages: {title}")
        return True
    except subprocess.CalledProcessError as e:
        log.error(f"Git push failed: {e}")
        return False


# ─── Main ────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="SEO Blog Generator")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--topic", type=str, help="Specific topic to write about")
    args = parser.parse_args()

    log.info("Starting blog generation")

    import random
    topic = args.topic or random.choice(BLOG_TOPICS)
    log.info(f"Topic: {topic}")

    post = generate_blog_post(topic)
    if not post or not post.get("body"):
        log.error("Failed to generate blog post")
        sys.exit(1)

    filepath = write_blog_file(post)
    log.info(f"Generated: {post['title']}")

    if BLOG_DIR.exists() and (BLOG_DIR / ".git").exists():
        git_push(filepath, post["title"], args.dry_run)
    else:
        log.warning(f"Blog directory {BLOG_DIR} is not a git repo. Skipping push.")
        log.info("To enable auto-push, clone your GitHub Pages repo to the BLOG_DIR path")

    log.info("Blog generation complete")


if __name__ == "__main__":
    main()
