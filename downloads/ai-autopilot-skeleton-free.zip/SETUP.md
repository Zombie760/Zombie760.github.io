# AI Business Autopilot — Setup Guide

> **Estimated time: 2-4 hours for basic setup. Full automation in 48 hours.**

This guide walks you through setting up your autonomous business system from scratch. No coding experience needed — if you can follow instructions, you can run this.

## Choose Your AI Mode

Before starting, decide how you want to run your AI:

| Mode | Difficulty | Cost | Privacy |
|------|-----------|------|---------|
| **Cloud APIs** (recommended to start) | Easy | ~$0.02/day | Standard |
| **Free APIs** | Easy | $0 | Standard |
| **Local AI (LM Studio)** | Advanced | $0 | Maximum |

**Start with Cloud APIs.** You can always switch to local later. The Boss tier ($29/mo) includes the full offline guide.

## Prerequisites

### Hardware
- Any laptop or desktop (Linux recommended, Mac works, Windows via WSL2)
- 8GB+ RAM minimum
- 16GB+ RAM if running local AI models (Boss tier)
- GPU with 8GB+ VRAM for local models (optional, Boss tier)
- Reliable internet connection (not needed for local AI mode)

### Accounts You'll Need (All Free)

1. **Telegram** — Download the app, create an account
2. **Twitter/X** — Create a developer account at developer.x.com
3. **GitHub** — Sign up at github.com
4. **Stripe** — Sign up at stripe.com (free, only charges per transaction)
5. **AI Provider** — Choose one:
   - xAI (Grok) at x.ai — fast, affordable
   - OpenAI at platform.openai.com — most popular
   - Any OpenAI-compatible provider
   - LM Studio (free, local) — Boss tier guide covers full setup
6. **Reddit** — Create account (needs 30 days to age before API access)

---

## Step 1: Install System Dependencies

### Ubuntu/Debian
```bash
sudo apt update && sudo apt install -y python3 python3-pip nodejs npm git curl
```

### Fedora/RHEL
```bash
sudo dnf install -y python3 python3-pip nodejs npm git curl
```

### Mac
```bash
brew install python3 node git
```

### Install Python Libraries
```bash
pip3 install tweepy praw requests python-dotenv openai
```

### Install Node.js Package Manager
```bash
npm install -g pnpm
```

---

## Step 2: Create Your Telegram Bots

1. Open Telegram and search for **@BotFather**
2. Send `/newbot`
3. Name your bot (e.g., "My Business Assistant")
4. Save the token — this is your `TELEGRAM_BUSINESS_BOT_TOKEN`
5. Send `/setdescription` to set what users see when they open your bot
6. Send `/setabouttext` to set the short bio

### Create Your Telegram Channel
1. In Telegram, tap "New Channel"
2. Name it (your brand name)
3. Make it public
4. Add your bot as admin (with post permissions)
5. Get the channel ID:
   - Post something in the channel
   - Forward it to @userinfobot
   - The chat ID (negative number) is your channel ID

---

## Step 3: Get Your API Keys

### Twitter/X API
1. Go to developer.x.com
2. Sign up for free tier (500 posts/month)
3. Create a Project → Create an App
4. Set permissions to "Read and Write"
5. Generate your keys:
   - Consumer Key → `TWITTER_CONSUMER_KEY`
   - Consumer Secret → `TWITTER_CONSUMER_SECRET`
   - Access Token → `TWITTER_ACCESS_TOKEN`
   - Access Token Secret → `TWITTER_ACCESS_TOKEN_SECRET`

### xAI (Grok)
1. Go to x.ai
2. Create an account and generate an API key
3. Save as `XAI_API_KEY`

### Stripe
1. Go to stripe.com → Developers → API Keys
2. Copy your Secret Key → `STRIPE_SECRET_KEY`
3. Copy your Publishable Key → `STRIPE_PUBLISHABLE_KEY`

### GitHub Token
1. Go to github.com → Settings → Developer settings → Personal access tokens
2. Generate a token with `repo` scope
3. Save as `GITHUB_TOKEN`

---

## Step 4: Configure Environment

```bash
# Create your working directory
mkdir -p ~/ai-autopilot
cd ~/ai-autopilot

# Copy the config files from this skeleton
cp -r config/ ~/ai-autopilot/
cp -r scripts/ ~/ai-autopilot/

# Set up your environment
cp config/.env.example .env
chmod 600 .env
```

Edit `.env` with your actual API keys:
```bash
nano .env
```

---

## Step 5: Install OpenClaw Gateway

```bash
# Install OpenClaw
pnpm install -g openclaw

# Verify installation
openclaw --version
```

### Configure OpenClaw
1. Copy `config/openclaw.json` to `~/.openclaw/openclaw.json`
2. Update the bot token placeholder with your actual token
3. Verify the config:
```bash
openclaw config check
```

---

## Step 6: Set Up AI Cron Jobs

Copy `config/jobs.json` to `~/.openclaw/cron/jobs.json`:
```bash
mkdir -p ~/.openclaw/cron
cp config/jobs.json ~/.openclaw/cron/jobs.json
```

### Customize the Jobs
Open `jobs.json` and replace all placeholder values:
- `[YOUR BRAND]` → Your business name
- `[YOUR STORY]` → Your brand story (1-2 sentences)
- `[YOUR URL]` → Your website URL
- `YOUR_CHANNEL_ID_HERE` → Your Telegram channel ID
- `YOUR_OWNER_ID_HERE` → Your personal Telegram user ID
- `GENERATE-YOUR-OWN-UUID-*` → Generate real UUIDs at uuidgenerator.net

---

## Step 7: Configure System Crontab

```bash
# Open your crontab
crontab -e

# Paste the contents of config/crontab.txt
# Update all /path/to/ entries with your actual paths
```

### Important: Update Script Paths
In each crontab line, replace:
- `/path/to/scripts/` → `~/ai-autopilot/scripts/`
- `/path/to/logs/` → `~/ai-autopilot/logs/`

Create the logs directory:
```bash
mkdir -p ~/ai-autopilot/logs
```

---

## Step 8: Customize Scripts

### auto-post.py
Open the script and update:
- Your brand name and tagline
- Your website URL
- Your Twitter handle
- Content topics relevant to your industry

### blog-generator.py
Update:
- Your GitHub Pages repository name
- Your brand information
- Blog topics for your niche

### twitter-engage.py
Update:
- Keywords to search for in your industry
- Accounts to follow
- Reply templates

---

## Step 9: Start the System

### Start OpenClaw Gateway
```bash
openclaw start
```

Or run as a system service:
```bash
# Create systemd service
sudo nano /etc/systemd/system/openclaw-gateway.service
```

Add:
```ini
[Unit]
Description=OpenClaw AI Gateway
After=network.target

[Service]
Type=simple
User=YOUR_USERNAME
ExecStart=/usr/local/bin/openclaw start
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Then:
```bash
sudo systemctl enable openclaw-gateway
sudo systemctl start openclaw-gateway
```

### Verify Everything is Running
```bash
# Check gateway status
openclaw status

# Check cron jobs
crontab -l

# Check logs
tail -f ~/ai-autopilot/logs/auto-post.log
```

---

## Step 10: Set Up GitHub Pages (Blog)

1. Create a new repository on GitHub (e.g., `yourbrand.github.io`)
2. Enable GitHub Pages in Settings → Pages
3. Clone it locally:
```bash
git clone https://github.com/yourusername/yourbrand.github.io.git
cd yourbrand.github.io
```
4. Copy the templates:
```bash
cp -r templates/website/* .
cp templates/sitemap.xml .
cp templates/robots.txt .
```
5. Push:
```bash
git add . && git commit -m "Initial site" && git push
```

---

## Verification Checklist

After setup, verify each component:

- [ ] `.env` file has all keys filled in (chmod 600)
- [ ] OpenClaw gateway is running (`openclaw status`)
- [ ] Telegram bot responds to `/start` command
- [ ] Cron jobs are loaded (`crontab -l`)
- [ ] Logs directory exists and scripts can write to it
- [ ] Twitter API test: `python3 scripts/auto-post.py --dry-run`
- [ ] Blog generator test: `python3 scripts/blog-generator.py --dry-run`
- [ ] GitHub Pages site is accessible

---

## Common First-Run Issues

### "Bot not responding"
- Check that your bot token is correct in `.env`
- Verify OpenClaw gateway is running
- Make sure the bot hasn't been revoked in @BotFather

### "Twitter API 403"
- Verify your app has "Read and Write" permissions
- Regenerate your access tokens after changing permissions
- Free tier limit: 500 posts/month

### "Cron jobs not firing"
- Check `crontab -l` to verify they're registered
- Check log files for errors
- Verify Python path: `which python3`

### "AI responses are empty"
- Verify your API key is valid
- Check your account has credits
- Test with a simple curl request first

---

## Next Steps

Once the basic system is running:

1. **Monitor logs** for the first 24-48 hours
2. **Adjust content prompts** to match your brand voice
3. **Add your products to Stripe** for auto-fulfillment
4. **Grow your Telegram channel** — the bots handle content

### Want the Full System?

This skeleton includes 3 of 13 AI agents. The full system adds:
- Revenue Strategist (brainstorms income 24/7)
- Product Architect (designs sellable products)
- Opportunity Hunter (scans the web for leads)
- Competitor Disruptor (finds competitor weaknesses)
- Stripe Auto-Fulfillment (hands-free sales)
- And 5 more specialized agents

**Hustler tier ($9/mo)** — All 13 agents, all scripts, full cloud config.

### Want to Go Completely Off-Grid?

The **Boss tier ($29/mo)** includes the full guide to running your AI 100% locally using LM Studio:

- Host your own AI model on your hardware
- No API keys needed — zero cloud dependency
- Your business data never leaves your machine
- No rate limits, no usage fees, no big tech surveillance
- Works on airplane mode — true doomsday-prepper grade
- Custom model fine-tuning for your specific industry

Big tech is already making it harder to run independent AI. OpenAI, Google, and Microsoft want you locked into their ecosystems paying monthly rent. The Boss tier teaches you how to never need them.

**Start free, upgrade when ready**: https://Zombie760.github.io/#pricing

---

*Built by SGKx1904 — a plumber who built an AI empire. If I can do it, you can too.*

*The tools are free. The knowledge is almost free. Big tech's patience is running out.*
